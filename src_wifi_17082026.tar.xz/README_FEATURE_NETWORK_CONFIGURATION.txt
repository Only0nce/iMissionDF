iScanMR10 - Network Configuration build feature
=================================================

Feature flag
------------
File: iScanMR10.pro

Enabled (default in this package):
    CONFIG += FEATURE_NETWORK_CONFIGURATION

Disabled:
    Comment out the line above, then rerun qmake and rebuild.

Generated C/C++ macro
---------------------
Enabled:
    FEATURE_NETWORK_CONFIGURATION=1

Disabled:
    FEATURE_NETWORK_CONFIGURATION=0

QML runtime property
--------------------
main.cpp exposes:
    FeatureNetworkConfiguration

Scope controlled by this feature
--------------------------------
1. Unified Network Settings page (Setting.qml: LAN / WiFi / 5G)
2. NETWORK SETTINGS entry in SideSettingsDrawer.qml
3. Top Network Configuration grab handle/drawer in MainPage.qml
4. Legacy Setting route in main.qml

Hardware capability remains independent
---------------------------------------
HW_5G / HW_NONE_5G still control WiFi and 5G availability.
LAN remains available when the Network Configuration feature is enabled.

Rebuild example
---------------
    make clean
    qmake iScanMR10.pro -spec linux-jetson-orin-g++
    make -j$(nproc)
